package oop;

public class TestStatic {
    int x;
    public static void main(String[] args) {
        TestStatic testStatic = new TestStatic();
        testStatic.x = 5;
    }
}
