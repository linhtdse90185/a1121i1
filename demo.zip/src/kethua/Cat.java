package kethua;

public class Cat extends Animal {

    @Override
    public void speak() {

    }

    @Override
    public void eat() {

    }

    @Override
    public Animal getAnimal() {
        return null;
    }
}
