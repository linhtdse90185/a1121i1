package demo.info;


import oop.*;


public class Test {
    public static void main(String[] args) {
        Student student = new Student();
        Test2 test2 = new Test2();
    }
}
