package demo.info;

import oop.Student;

public class StudentDuyTan extends Student {
    public static void main(String[] args) {
        StudentDuyTan a = new StudentDuyTan();
        a.name = "Hung";
    }
}
