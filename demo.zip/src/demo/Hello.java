package demo;

public class Hello {
    static int x;
    public static void main(String[] args) {
        System.out.println("Hello world");
        float x;
        x = 4.5f + 4;
        boolean isFlag = true;
        double y = x;
//        System.out.println(5f/2);
        System.out.println(x);
    }
}
