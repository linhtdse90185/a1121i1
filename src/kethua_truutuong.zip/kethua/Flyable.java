package kethua;

public interface Flyable {
    int a = 1;
    void fly();
}
