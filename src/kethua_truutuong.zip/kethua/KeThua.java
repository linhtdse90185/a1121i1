package kethua;

public class KeThua {
    public static void main(String[] args) {
        Animal animal = new Animal() {
            @Override
            public void speak() {

            }

            @Override
            public void eat() {

            }

            @Override
            public Animal getAnimal() {
                return null;
            }
        };
    }
}
