package kethua;

public class Parrot extends Bird {

    @Override
    public void speak() {

    }

    @Override
    public void eat() {

    }

    @Override
    public Animal getAnimal() {
        return null;
    }

    @Override
    public void fly() {

    }
}
