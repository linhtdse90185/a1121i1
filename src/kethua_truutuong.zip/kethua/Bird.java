package kethua;

public abstract class Bird extends Animal implements Flyable {

}
