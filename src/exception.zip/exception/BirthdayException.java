package exception;

public class BirthdayException extends Exception {
    public BirthdayException() {
        super();
    }

    public BirthdayException(String message) {
        super(message);
    }
}
